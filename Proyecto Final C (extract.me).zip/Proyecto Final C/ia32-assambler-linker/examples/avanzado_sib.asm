SECTION .text
GLOBAL main
EXTERN printf

main:
    MOV EAX, [EBX+ECX*4+8]  ; Direccionamiento SIB
    CALL printf             ; Llamada a funcion externa
    RET